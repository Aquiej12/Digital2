Core/Src/gh_sprites.o: ../Core/Src/gh_sprites.c ../Core/Inc/gh_sprites.h
../Core/Inc/gh_sprites.h:
