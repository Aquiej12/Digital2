Core/Src/music.o: ../Core/Src/music.c ../Core/Inc/music.h \
 ../Core/Inc/notes.h ../Core/Inc/synth.h
../Core/Inc/music.h:
../Core/Inc/notes.h:
../Core/Inc/synth.h:
