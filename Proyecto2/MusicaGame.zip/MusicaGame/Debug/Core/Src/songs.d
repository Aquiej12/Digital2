Core/Src/songs.o: ../Core/Src/songs.c ../Core/Inc/songs.h \
 ../Core/Inc/music.h ../Core/Inc/notes.h ../Core/Inc/synth.h \
 ../Core/Inc/song_demo.h ../Core/Inc/synth.h \
 ../Core/Inc/song_seven_nation_army.h \
 ../Core/Inc/song_seven_nation_army_canal1.h \
 ../Core/Inc/song_seven_nation_army_canal2.h \
 ../Core/Inc/song_seven_nation_army_canal3.h \
 ../Core/Inc/song_b_e_r___the_night_begins_to_shine__wip.h \
 ../Core/Inc/song_b_e_r___the_night_begins_to_shine__wip_canal1.h \
 ../Core/Inc/song_b_e_r___the_night_begins_to_shine__wip_canal2.h \
 ../Core/Inc/song_b_e_r___the_night_begins_to_shine__wip_canal3.h \
 ../Core/Inc/song_mighty_morphin_power_rangers.h \
 ../Core/Inc/song_michael_jackson___beat_it.h \
 ../Core/Inc/song_michael_jackson___beat_it_canal1.h \
 ../Core/Inc/song_michael_jackson___beat_it_canal2.h \
 ../Core/Inc/song_michael_jackson___beat_it_canal3.h \
 ../Core/Inc/song_pokemon_black_and_white_low_hp_midi_version.h \
 ../Core/Inc/song_pokemon_black_and_white_low_hp_midi_version_canal1.h \
 ../Core/Inc/song_pokemon_black_and_white_low_hp_midi_version_canal2.h \
 ../Core/Inc/song_pokemon_black_and_white_low_hp_midi_version_canal3.h
../Core/Inc/songs.h:
../Core/Inc/music.h:
../Core/Inc/notes.h:
../Core/Inc/synth.h:
../Core/Inc/song_demo.h:
../Core/Inc/synth.h:
../Core/Inc/song_seven_nation_army.h:
../Core/Inc/song_seven_nation_army_canal1.h:
../Core/Inc/song_seven_nation_army_canal2.h:
../Core/Inc/song_seven_nation_army_canal3.h:
../Core/Inc/song_b_e_r___the_night_begins_to_shine__wip.h:
../Core/Inc/song_b_e_r___the_night_begins_to_shine__wip_canal1.h:
../Core/Inc/song_b_e_r___the_night_begins_to_shine__wip_canal2.h:
../Core/Inc/song_b_e_r___the_night_begins_to_shine__wip_canal3.h:
../Core/Inc/song_mighty_morphin_power_rangers.h:
../Core/Inc/song_michael_jackson___beat_it.h:
../Core/Inc/song_michael_jackson___beat_it_canal1.h:
../Core/Inc/song_michael_jackson___beat_it_canal2.h:
../Core/Inc/song_michael_jackson___beat_it_canal3.h:
../Core/Inc/song_pokemon_black_and_white_low_hp_midi_version.h:
../Core/Inc/song_pokemon_black_and_white_low_hp_midi_version_canal1.h:
../Core/Inc/song_pokemon_black_and_white_low_hp_midi_version_canal2.h:
../Core/Inc/song_pokemon_black_and_white_low_hp_midi_version_canal3.h:
